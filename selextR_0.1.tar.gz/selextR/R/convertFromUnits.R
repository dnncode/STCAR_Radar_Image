#' Convert from physical units
#' 
#' Converts the the radar into the physical units into 8-bit readings.
#'
#' @param data This contains the data. Usually a scalar.
#' @param prod.type This is a character vector of length 1, and it specifies 
#' what the product type is. It has to be one of those specified in the formal
#' argument for now.
#'
#' @details This function is primarily for computing the 0...255 value that is
#' required as an input for the storm detection routines
#' \code{\link{stormDetectionR}}
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' data <- c(30, 70, 45)
#' convertFromUnits(data, "dBZ")
#'
#' @return Returns an object of the same type as earlier, but with the 8 bit
#' value that comes from Selex.

convertFromUnits <- function(data, prod.type=c("dBZ", "V", "W")) {
  if(prod.type == "dBZ") 
    return(round((data + 32)*2)) else
  if(prod.type == "W") 
    return(round(data*(254/15) + 1)) else
  if(prod.type == "V") 
    return(round((data+30)*(254/60) + 1))
}
