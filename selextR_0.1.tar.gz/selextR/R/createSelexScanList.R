#' Create a scan object
#' 
#' A scan object consists of several time-stamps, and various radar CAPPI
#' products in one list object.
#'
#' @param fname The name of the file containing the json output of rbclient.
#' @param proj The projection to work with. It has to be one of "latLong" or 
#' "svy21"
#' @param rm.file A logical argument to indicate if the file should be removed
#' after being read in.
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='tmp1')}
#' \dontrun{out <- createSelexScan('tmp1')}
#' \dontrun{class(out)}
#'
#' @seealso
#' \code{\link{plot.SelexScan}}
#' 
#' @return Returns a list of class "SelexScanList". Each element in the list is
#' class "SelexScan".

createSelexScanList <- function(fname, proj = "svy21", rm.file=FALSE) {
  json.string <- readLines(fname, warn=FALSE)

  if(length(json.string) == 0)
    stop("No scans found in file\n")

  if(proj == "svy21")
    proj4 <- svy21Proj else
  if(proj == "latLong")
    proj4 <- latLongProj else
  stop("Unknown projection system.\n")

  out <- NULL
  for(ii in 1:length(json.string)) {
    json2 <- fromJSON(json_str=json.string[ii])
    tstamp <- roundTime(names(json2))
    json2 <- json2[[1]]
    for(jj in 1:length(json2)) {
      ht <- names(json2)[jj]
      ht <- as.numeric(substring(ht, first=2))
      # cat("Height is ", ht, "\n")
      json3 <- json2[[jj]]
      for(kk in 1:length(json3)) {
        prod.type <- names(json3)[kk]
        prod.type <- strsplit(prod.type, "\\.")[[1]][1]
        # cat("Prod is ", prod.type, "\n")
        json4 <- json3[[kk]]
        nrows1 <- json4$rows
        ncols1 <- json4$cols
        dat1 <- json4$data
        id <- sapply(dat1, function(z) z[1]*ncols1+z[2]+1)
        val <- sapply(dat1, function(z) z[3])
        curPlot <- rep(0, nrows1*ncols1)
        curPlot[id] <- val 
        curPlot <- convertToUnits(curPlot, prod.type)
 
        # Set up spatial grid object
	bboxCoords <- c(json4$startpoint, json4$endpoint)

	topAndBot <- matrix(bboxCoords, nrow=2, byrow=TRUE)
	topAndBot <- topAndBot[, c(2,1)]
	topAndBot <- SpatialPoints(topAndBot, CRS(latLongProj))
	top2 <- spTransform(topAndBot, CRS(proj4))

        # Prepare inputs to create the grid
	newCoords <- coordinates(top2)
	cellCentreOffset <- c(newCoords[1,1], newCoords[2,2])
	cellDims <- c(ncols1, nrows1)
	cellSize <- abs((newCoords[2,] - newCoords[1,])/cellDims)

	grdTopo = GridTopology(cellCentreOffset, cellSize, cellDims)
	spatGrd = SpatialGrid(grid=grdTopo, CRS(proj4))
	spatDat <- SpatialGridDataFrame(spatGrd, data.frame(curPlot))
        
        singleObj <- list(timestamp=tstamp, height=ht, prod.type=prod.type,
          data=spatDat, spat.agg=NULL)
        class(singleObj) <- "SelexScan"
   
        out <- c(out, list(singleObj))
      }
    }
  }

  if(rm.file)
    unlink(fname)

  tstamps <- sapply(out, function(y) y$timestamp)
  heights <- sapply(out, function(y) y$height)
  prod.type <- sapply(out, function(y) y$prod.type)

  outMat <- data.frame(Timestamps=tstamps, Heights=heights, Prod.type=prod.type, 
    stringsAsFactors=FALSE)
  id <- order(outMat$Timestamps, outMat$Heights, outMat$Prod.type)
  out <- out[id]

  class(out) <- "SelexScanList"
  cat(nrow(outMat), "scan objects created.", "\n")
  return(out)
}
