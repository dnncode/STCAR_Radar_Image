#' Create a stormTrack object.
#' 
#' Creates an associated list of storm objects that can be plotted or analysed.
#'
#' @param x An object of class stormList.
#'
#' @export
#' @author Vik Gopal
#'
#' @details This function returns an object of class stormTrack. These objects
#' are plotted differently from storm lists, as the storms from time-stamp to
#' time-stamp are associated. Later this will be created differently, but for
#' now they rely on the user picking out the storm ids that are related.
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{class(storm.list)}
#' \dontrun{summary(storm.list)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{class(storm.track)}
#'
#' @seealso \code{\link{createStormList}}, \code{\link{plot.stormTrack}}
#'
#' @return Returns an object of class stormTrack. This is a list of objects of
#' class "storm", just like stormList, but the storms are from consecutive
#' time-stamps, and are 'connected'.

createStormTrack <- function(x) {
  if(class(x) != "stormList")
    stop("x should be of class 'stormList'\n")
  class(x) <- c("stormTrack", "stormList")
  x
}
