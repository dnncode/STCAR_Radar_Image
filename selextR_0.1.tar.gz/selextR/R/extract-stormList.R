#' Extract subset of storms
#' 
#' Extracts a subset of storms from 
#'
#' @aliases `[.stormList`
#'
#' @param x An object of class stormList
#' @param i An integer vector to select the storms of interest.
#' @param ... Unused for now.
#'
#' @method [ stormList
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{sub1 <- storm.list[c(1,2)]}
#' \dontrun{summary(sub1)}
#' \dontrun{plot(sub1, height=3)}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns an object of class stormList

`[.stormList` <- function(x, i, ... ) {
  class(x) <- "list"
  out <- x[i]
  class(out) <- "stormList"
  out
}
