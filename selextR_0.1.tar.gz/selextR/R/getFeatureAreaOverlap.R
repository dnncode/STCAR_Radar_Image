#' Extract overlap area
#' 
#' Extract area of overlap with Singapore mainland
#'
#' @param obj An object of class storm
#' @param ... If it contains a logical flag, stations=TRUE, then a logical 
#' matrix reflecting which stations were affected by this storm will also be 
#' returned.
#'
#' @details This extracts the area of overlap with the convex hull around the 
#' mainland of Singapore, as given by sgBd[50,].
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing the area overalapped by the individual heights.

getFeatureAreaOverlap <- function(obj, ...) {
  args.list <- list(...)
  if("stations" %in% names(args.list))
    stations <- args.list$stations

  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
  
  projected.poly <- NULL
  overlap.area <- rep(NA, length(ht.vector)+1)

  for(i in 1:length(ht.vector)) {
    tmp.poly <- extractConvexHullFromStorm(obj, height=ht.vector[i])
    tmp.poly <- Polygons(list(tmp.poly), 'A')
    tmp.poly <- SpatialPolygons(list(tmp.poly), proj4string=CRS(svy21Proj))
    if(is.null(projected.poly))
      projected.poly <- tmp.poly else 
      projected.poly <- gUnion(tmp.poly, projected.poly)
    area <- gIntersection(tmp.poly, gConvexHull(sgBd[50,]))
    if(is.null(area))
      overlap.area[i] <- 0 else
      overlap.area[i] <- gArea(area)/1e+06
  }
  area <- gIntersection(projected.poly, gConvexHull(sgBd[50,]))
  if(is.null(area))
    overlap.area[length(ht.vector)+1] <- 0 else
    overlap.area[length(ht.vector)+1] <- gArea(area)/1e+06
 
  overlap.area <- matrix(overlap.area, nrow=1)
  overlap.area <- as.data.frame(overlap.area)
  colnames(overlap.area) <- c(paste("AreaOverlap", ht.vector, sep="."),
    "AreaOverlap.proj")

  if(stations==TRUE) {
    overlap.stn <- !is.na(over(stns, projected.poly))
    overlap.stn <- matrix(overlap.stn, nrow=1)
    overlap.stn <- as.data.frame(overlap.stn)
    colnames(overlap.stn) <- paste("S", stns$Stn, sep=".")
    overlap.area <- cbind(overlap.area, overlap.stn)
  }
  overlap.area
}
