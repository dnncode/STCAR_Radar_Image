#' Extract height
#' 
#' Extract height of a storm centroid
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the height of the 3-D storm in pixels.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector of length 2 with the minimum and maximum heights of a storm.

getFeatureHeight <- function(obj, ...) {
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  ht.range <- range(ht.vector)
  ht.range <- matrix(ht.range, nrow=1)
  ht.range <- as.data.frame(ht.range)
  colnames(ht.range) <- c("min.ht", "max.ht")

  ht.range
}
