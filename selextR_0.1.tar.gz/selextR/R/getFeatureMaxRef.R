#' Extract maximum reflectivity
#' 
#' Extract the maximum reflectivity value at each height available.
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the size of the storm in pixels at the specified
#' height. This is not meant to be used on its own, but rather to be called by
#' getFeatures function.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeatureMaxRef <- function(obj, ...) {

  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  max.ref <- unlist(lapply(obj$data, function(x) max(x$sp.pts$dBZ, na.rm=TRUE)))

  max.ref <- matrix(max.ref, nrow=1)
  max.ref <- as.data.frame(max.ref)
  colnames(max.ref) <- paste("MaxRef", ht.vector, sep=".")
  max.ref
}
