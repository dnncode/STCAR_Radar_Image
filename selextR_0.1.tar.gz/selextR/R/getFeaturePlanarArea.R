#' Extract planar area
#' 
#' Extract planar area in pixels from a single timestamp of a storm object.
#'
#' @param obj An object of class storm
#' @param ... This list of arguments MUST contain an argument for height.
#'
#' @details This extracts the size of the storm in pixels at the specified
#' height. This is not meant to be used on its own, but rather to be called by
#' getFeatures function.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeaturePlanarArea <- function(obj, ...) {

  args.list <- list(...)
  if(!("height" %in% names(args.list)))
    stop("'height' argument has to be provided for getFeaturePlanarArea()")

  height <- args.list$height
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  id <- match(height, ht.vector)
  which.na <- which(is.na(id))

  if(length(which.na) == 0) {
    areas <- unlist(lapply(obj$data[id], function(x) length(x$sp.pts)))
  } else {
    areas <- rep(NA, length(height))
    areas[-which.na] <- unlist(lapply(obj$data[id[-which.na]], function(x) 
      length(x$sp.pts)))
  }
 
  areas <- matrix(areas, nrow=1)
  areas <- as.data.frame(areas)
  colnames(areas) <- paste("PlanarArea", height, sep=".")
  areas
}
