#' Extract volume
#' 
#' Extract volume of a storm centroid.
#'
#' @param obj An object of class storm
#' @param ... Unused for now.
#'
#' @details This extracts the size of the 3-D storm in pixels.
#'
#' @export
#' @author Vik Gopal
#'
#' @return A vector of length 1 with the size of the storm.

getFeatureVolume <- function(obj, ...) {
  ht.vector <- unlist(lapply(obj$data, function(x) x$height))
 
  vols <- sum(getFeaturePlanarArea(obj, height=ht.vector), na.rm=TRUE)

  vols <- matrix(vols, nrow=1)
  vols <- as.data.frame(vols)
  colnames(vols) <- "Volume"
  vols
}
