#' Extract features
#' 
#' Extract features for a stormList or stormTrack object.
#'
#' @aliases getFeatures.stormTrack
#'
#' @param obj An object of class stormList or stormTrack
#' @param features A character vector of features to be extracted. If it is
#' equal to "list", then all functions in the package with "getFeaturexxx" are
#' listed.
#' @param ... This will contain arguments that will be passed to the individual
#' getFeature functions, e.g. height for getFeaturePlanarArea.
#'
#' @details This extracts the specified features for a stormList or stormTrack 
#' object.
#'
#' @method getFeatures stormList
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#'
#' @return A vector containing the sizes at the specified heights. It will
#' contain an NA  if there is no data for that height.

getFeatures.stormList <- function(obj, features, ...) {

  out <- ldply(obj, getFeatures, features=features, ...)
  out
}
