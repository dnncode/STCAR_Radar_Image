#' Extract features
#' 
#' Extract features for a storm or stormTrack object.
#'
#' @param obj An object of class storm or stormTrack.
#' @param ... Unused for now.
#'
#' @details This extracts the specified features for a single storm object.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns whatever the specific method returns.

getFeatures <- function(obj, ...) {
  UseMethod("getFeatures")
}
