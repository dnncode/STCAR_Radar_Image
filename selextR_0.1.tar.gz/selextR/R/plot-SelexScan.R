#' Plot a radar scan
#' 
#' Plot a SelexScan object.
#'
#' @param x An object of class SelexScan.
#' @param y If not null, then this should be an object of class stormList,
#' containing the timestamp in x.
#' @param boundaries Logical value, indicating if country boundaries should be
#' plotted or not.
#' @param convex.hull Logical value, indicating if the convex hull of the storm
#' should be plotted.
#' @param ... Unused for now.
#'
#' @method plot SelexScan
#'
#' @examples
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='tmp1')}
#' \dontrun{out <- createSelexScan('tmp1')}
#' \dontrun{class(out)}
#' \dontrun{plot(out[[1]])}
#'
#' @seealso
#' \code{\link{spatAgg.SelexScan}}, \code{link{rbclientR}},
#' \code{link{createSelexScanList}}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned.

plot.SelexScan <- function(x, y=NULL, boundaries=FALSE, convex.hull=FALSE, ...) {
  ht <- x$height
  tstamp <- as.character(x$timestamp)
 
  if(!is.null(y)) {
    if(class(y) != "stormList") 
      stop("2nd argument should be of class 'stormList'")
    storm.tstamps <- sapply(y, function(z) as.character(z$timestamp))
    if(!(tstamp %in% storm.tstamps)) 
      stop("Storm list does not contain matching timestamps!")

    keep.these.storms <- which(storm.tstamps == tstamp)
    y2 <- y[keep.these.storms]
    storm.polys <- llply(y2, extractStormOutline, height=ht,
      convex.hull=convex.hull)

    # Check if any of the storms do not have components at the specified height:
    which.na <- sapply(storm.polys, function(x) class(x) != "SpatialPolygons")
    if(sum(which.na) == length(which.na))
      stop(paste("No storms found at height of", ht, "km.", sep=" "))
    if(sum(which.na) > 0) {
      cat("The following storm indices did not have components at height of",
	ht, "km:\n ", sep=" ")
      cat(which(which.na), "\n")
      storm.polys <- storm.polys[!which.na]
    }

    storm.poly.list <- llply(storm.polys, function(x) list("sp.polygons", x,
      border='steelblue1', lwd=2, first=FALSE))
  }

  if(boundaries) {
    singList <- list("sp.polygons", sgBd)
    myList <- list("sp.polygons", myBd)
    inList <- list("sp.polygons", inBd)
    if(!is.null(y)) {
      sp.layout.list <- vector(mode="list", length=3+length(storm.poly.list))
      sp.layout.list[1:3] <- list(singList, myList, inList)
      sp.layout.list[-(1:3)] <- storm.poly.list
    } else
      sp.layout.list <- list(singList, myList, inList)
  } else {
    if(!is.null(y))
      sp.layout.list <- storm.poly.list else
      sp.layout.list <- NULL
  }

  if(is.null(x$spat.agg))
    sub1 <- "No spatial aggregation" else
    sub1 <- paste("Spatial agg: ", x$spat.agg[1], ",", x$spat.agg[2], sep="")

  if(x$prod.type == "dBZ") {
    colorPalette1 <- rev(rainbow(32, start=5/6, end=3/6, alpha=0.8))
    at.points <- seq(from=0, to=75, length=33)
  } else if (x$prod.type == "V") { # for V:
    tmp1 <- col2rgb(colorRampPalette(c("red", "dark grey", "green"))(32))
    colorPalette1 <- rgb(tmp1[1,], tmp1[2,], tmp1[3,], alpha=200,
      maxColorValue=255)
    at.points <- seq(from=-10, to=10, length=33)
  } else if (x$prod.type == "W") { # for W:
    tmp1 <- col2rgb(colorRampPalette(c("blue", "red"))(32))
    colorPalette1 <- rgb(tmp1[1,], tmp1[2,], tmp1[3,], alpha=200,
      maxColorValue=255)
    at.points <- seq(from=0, to=15, length=33)
  }

  print(spplot(x$data, 'curPlot', scales=list(draw=TRUE),
       sp.layout=sp.layout.list,
       at=at.points, col.regions=colorPalette1,
       main=paste(tstamp, " UTC @", ht, "km", sep=""),
       sub=sub1, ...))

}
