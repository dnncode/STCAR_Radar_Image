#' Plot a list of storms
#' 
#' Plot a stormList object.
#'
#' @param x An object of class stormList.
#' @param y This is unused here.
#' @param boundaries Logical value, indicating if country boundaries should be
#' plotted or not.
#' @param height The height of the storm objects to be plotted
#' @param convex.hull Logical argument, indicating if the convex hull of the
#' storm should be plotted, or if the actual polygon boundary should be plotted.
#' @params labels A logical argument, to indicate if centroid labels should be
#' added to the storm shapes.
#' @param ... Unused for now.
#'
#' @method plot stormList
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{plot(storm.list, height=2)}
#' \dontrun{plot(storm.list, height=2, convex.hull=TRUE)}
#'
#' @export
#' @author Vik Gopal
#'
#' @return Nothing returned.

plot.stormList <- function(x, y=NULL, boundaries=FALSE, height=1, 
  convex.hull = FALSE, labels=FALSE, ...) {

  storm.polys <- llply(x, extractStormOutline, height=height,
    convex.hull=convex.hull)

  # Check if any of the storms do not have components at the specified height:
  which.na <- sapply(storm.polys, function(x) class(x) != "SpatialPolygons")
  if(sum(which.na) == length(which.na))
    stop(paste("No storms found at height of", height, "km.", sep=" "))
  if(sum(which.na) > 0) {
    cat("The following storm indices did not have components at height of",
      height, "km:\n ", sep=" ")
    cat(which(which.na), "\n")
    storm.polys <- storm.polys[!which.na]
  }

  if(labels) {
    centroid <- ldply(storm.polys, function(x) coordinates(x))
    centroid <- centroid[, -1]
  }

  args1 <- names(as.list(match.call()[-1]))
  if(!("xlim" %in% args1))
    xlim <- c(-70000, 170000) else
    xlim <- eval(as.list(match.call())["xlim"][[1]])
  if(!("ylim" %in% args1))
    ylim <- c(-75000, 150000) else
    ylim <- eval(as.list(match.call())["ylim"][[1]])

  plot(sgBd, axes=TRUE, xlim=xlim, ylim=ylim)
  plot(inBd, add=TRUE)
  plot(myBd, add=TRUE)

  l_ply(storm.polys, plot, add=TRUE, col='red', border='orange')
  title(paste("Storm objects @", height, "km", sep=""))

  if(labels)
    text(centroid, labels=(1:length(x))[!which.na], col="blue")
}
