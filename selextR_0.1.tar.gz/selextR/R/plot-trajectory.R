#' Plot trajectory object
#' 
#' Plot a trajectory object
#'
#' @param x An object of class "trajectory".
#' @param y Unused for now.
#' @param bw Bandwidth parameter to be passed to smoothTrajectory.
#' @param add A logical parameter to convey if this is to be added to a plot or
#' displayed on a new device.
#' @param ... Unused for now.
#'
#' @method plot trajectory
#'
#' @details This function plots the trajectory object returned by
#' \code{\link{getTrajectory}}. This is meant more for plotting over the plot of
#' a storm track, which is why the add argument is explicitly there.
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{storm.track <- storms[c(2,5,7,9,10,13,15)]}
#' \dontrun{plot(storm.track)}
#' \dontrun{traj.obj <- getTrajectory(storm.track, centroid="ref")}
#' \dontrun{plot(traj.obj, bw=0), add=TRUE)}
#'
#' @return Returns nothing.

plot.trajectory <- function(x, y=NULL, bw=0, add=FALSE, ...) {
  l1 <- smoothTrajectory(x, bw=bw)

  plot(l1, axes=TRUE, col='red', add=add, ...)

  # Add arrows
  if(bw == 0) {
    ncoords <- nrow(x$coordinates)
    arrows(x$coordinates$x[ncoords-1], x$coordinates$y[ncoords-1],
	   x$coordinates$x[ncoords], x$coordinates$y[ncoords], col='red')
  } else {
    x.all <-  coordinates(l1)[[1]][[1]][,1]
    y.all <-  coordinates(l1)[[1]][[1]][,2]
    x0 <- x.all[length(x.all)-1]
    y0 <- y.all[length(y.all)-1]
    x1 <- x.all[length(x.all)]
    y1 <- y.all[length(y.all)]
    arrows(x0, y0, x1, y1, col='red')
  }
}
