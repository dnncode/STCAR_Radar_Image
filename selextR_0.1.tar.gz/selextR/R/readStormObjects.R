#' Read storm objects
#' 
#' Read in storm objects that were output by stormDetectionR.
#'
#' @param fname The file that contains the raw storm objects, as output by
#' stormDetectionR
#'
#' @details At the moment, this deals with the five levels of scans only (Note
#' how the columns are named in the output).
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{summary(storm.list)}
#'
#' @return Returns a data-frame that contains the storm objects.

readStormObjects <- function(fname) {
  storm.obj <- read.csv(fname, header=FALSE, stringsAsFactors=FALSE)
  split.vals <- strsplit(storm.obj$V5, " ")

  storm.id <- as.numeric(sapply(split.vals, function(x) x[3]))

  dateTime <- sapply(split.vals, function(x) paste(x[1:2], collapse=" "))
  dateTime <- as.POSIXct(roundTime(dateTime), format="%Y-%m-%d %H:%M:%S")

  x <- as.integer(storm.obj[,1])
  y <- as.integer(storm.obj[,2])
  z <- as.integer(storm.obj[,3]) + 1 # height of storm

  dBZ <- convertToUnits(storm.obj$V4, "dBZ")

  storm.obj <- data.frame(storm.id, x, y, z, dBZ, dateTime,
    stringsAsFactors=FALSE)

  storm.obj
}
