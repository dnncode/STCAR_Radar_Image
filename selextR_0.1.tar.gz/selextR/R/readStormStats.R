#' Read storm statistics.
#' 
#' Read in storm statistics that were output by stormDetectionR
#'
#' @param fname The file that contains the raw statistics, as output by
#' stormDetectionR
#'
#' @details At the moment, this deals with the five levels of scans only (Note
#' how the columns are named in the output).
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{summary(storm.list)}
#'
#' @return Returns a data-frame that contains the storm statistics.

readStormStats <- function(fname) {
  con1 <- file(fname, 'rt')
  
  stats1 <- readLines(con1)[-1]
  close(con1)

  out.mat <- matrix(NA, nrow=length(stats1), ncol=82)
  out.mat <- data.frame(dateTime=NA, out.mat)

  # This can soo be improved!
  for(i in 1:length(stats1)) {
    tmp <- strsplit(stats1[i], split=c("[ ,]"))[[1]]
    out.mat[i,1] <- paste(tmp[1:2], collapse=" ")
    out.mat[i,-1] <- as.numeric(tmp[-(1:2)])
  }
  
  rownames(out.mat) <- out.mat[,2]
  out.mat$dateTime <- sapply(out.mat$dateTime, roundTime, USE.NAMES=FALSE)
  out.mat$dateTime <- as.POSIXct(out.mat$dateTime,  format="%Y-%m-%d %H:%M:%S")
  
  colnames(out.mat)[-1] <- c("ID", "Centroid.x1", "Centroid.y1", "Centroid.z1", 
    "Pixel.Area.1", "Ref.wt.centroid.x1", "Ref.wt.centroid.y1",  "Ref.wt.centroid.z1",
    "Av.ref.1", "Max.ref.1", "Mean.vel.1", "StdDev.vel.1", "Mean.W.1", 
    "StdDevW.1", "Centroid.x2", "Centroid.y2", "Centroid.z2", 
    "Pixel.Area.2", "Ref.wt.centroid.x2", "Ref.wt.centroid.y2",  "Ref.wt.centroid.z2",
    "Av.ref.2", "Max.ref.2", "Mean.vel.2", "StdDev.vel.2", "Mean.W.2", 
    "StdDevW.2", "Centroid.x3", "Centroid.y3", "Centroid.z3", 
    "Pixel.Area.3", "Ref.wt.centroid.x3", "Ref.wt.centroid.y3",  "Ref.wt.centroid.z3",
    "Av.ref.3", "Max.ref.3", "Mean.vel.3", "StdDev.vel.3", "Mean.W.3", 
    "StdDevW.3", "Centroid.x4", "Centroid.y4", "Centroid.z4", 
    "Pixel.Area.4", "Ref.wt.centroid.x4", "Ref.wt.centroid.y4",  "Ref.wt.centroid.z4",
    "Av.ref.4", "Max.ref.4", "Mean.vel.4", "StdDev.vel.4", "Mean.W.4", 
    "StdDevW.4", "Centroid.x5", "Centroid.y5", "Centroid.z5", 
    "Pixel.Area.5", "Ref.wt.centroid.x5", "Ref.wt.centroid.y5",  "Ref.wt.centroid.z5",
    "Av.ref.5", "Max.ref.5", "Mean.vel.5", "StdDev.vel.5", "Mean.W.5", 
    "StdDevW.5", "Centroid.x", "Centroid.y", "Centroid.z", 
    "Pixel.Area", "Ref.wt.centroid.x", "Ref.wt.centroid.y",  "Ref.wt.centroid.z",
    "Av.ref", "Mean.vel", "StdDev.vel", "Mean.W", 
    "StdDevW", "Max.ref", "Height.max.ref", "Storm.ht", "Proj.Area")

#  # Carry out unit conversions
#  raw.ref <- out.mat[ , c("Av.ref.1", "Max.ref.1", "Av.ref.2", "Max.ref.2", "Av.ref.3", "Max.ref.3", 
#	      "Av.ref.4", "Max.ref.4", "Av.ref.5", "Max.ref.5", "Av.ref", "Max.ref")] 
#  out.mat[ , c("Av.ref.1", "Max.ref.1", "Av.ref.2", "Max.ref.2", "Av.ref.3", "Max.ref.3", 
#     "Av.ref.4", "Max.ref.4", "Av.ref.5", "Max.ref.5", "Av.ref", 
#     "Max.ref")]  <- convertToUnits(raw.ref, "dBZ")
#
#  raw.V <- out.mat[,c("Mean.vel.1", "StdDev.vel.1", "Mean.vel.2", "StdDev.vel.2",
#    "Mean.vel.3", "StdDev.vel.3", "Mean.vel.4", "StdDev.vel.4", "Mean.vel.5",
#    "StdDev.vel.5", "Mean.vel", "StdDev.vel")]
#  out.mat[,c("Mean.vel.1", "StdDev.vel.1", "Mean.vel.2", "StdDev.vel.2",
#    "Mean.vel.3", "StdDev.vel.3", "Mean.vel.4", "StdDev.vel.4", "Mean.vel.5",
#    "StdDev.vel.5", "Mean.vel", "StdDev.vel")] <- convertToUnits(raw.V, "V")
#
#  raw.W <- out.mat[,c("Mean.W.1", "StdDevW.1", "Mean.W.2", "StdDevW.2",
#    "Mean.W.3", "StdDevW.3", "Mean.W.4", "StdDevW.4", "Mean.W.5",
#    "StdDevW.5", "Mean.W", "StdDevW")]
#  out.mat[,c("Mean.W.1", "StdDevW.1", "Mean.W.2", "StdDevW.2",
#    "Mean.W.3", "StdDevW.3", "Mean.W.4", "StdDevW.4", "Mean.W.5",
#    "StdDevW.5", "Mean.W", "StdDevW")] <- convertToUnits(raw.W, "W")

  out.mat
}
