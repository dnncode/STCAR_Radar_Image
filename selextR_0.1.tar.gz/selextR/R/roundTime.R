#' Round a time-stamp
#' 
#' Rounds a time-stamp to the nearest minute
#'
#' @param t1 This argument should a character vector of length one, of the form
#' "yyyy-mm-dd HH:MM:SS".
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' start.time <- "2011-05-20 07:09:34"
#' roundTime(start.time)
#'
#' @return Returns a character vector of length one, with the seconds rounded to
#' be 00

roundTime <- function(t1) {
  paste(substring(t1, first=1, last=17), "00", sep="")
}
