#' Country boundaries
#' 
#' Documents the country boundaries included with this package.
#'
#' @name sgBd
#' @aliases inBd myBd stns svy21Proj latLongProj
#' @docType data
#'
#' @format inBd contains the boundary of Indonesia, myBd contains West Malaysia
#' and sgBd contains Singapore. All use the svy21 projection system. stns
#' contains the observation stations on Singapore. It also contains the
#' proj4string for svy21 (svy21Proj) and lat-long (latLongProj).
#'
NULL
