#' Spatial aggregation of scan
#' 
#' Generic function for aggregating spatial measurements from a radar scan.
#'
#' @param x An object of class SelexScan.
#' @param ... Extra arguments passed to the specific method.
#'
#' @export
#' @author Vik Gopal
#'
#' @return Returns whatever the specific method returns.
#'
#' @seealso \code{\link{spatAgg.SelexScan}}

spatAgg <- function(x, ...) {
  UseMethod("spatAgg")
}
