#' Summarize info in storms
#' 
#' Print a summary table of the information in a stormList object.
#'
#' @param object An object of class stormList.
#' @param verbosity An integer between 1 and 3 indicating verbosity. 1 is least
#' verbose and 3 is most verbose.
#' @param ... Unused for now.
#'
#' @method summary stormList
#'
#' @export
#' @author Vik Gopal
#'
#' @examples 
#' \dontrun{start.time <- "2011-05-20 07:09:00"}
#' \dontrun{end.time <- "2011-05-20 07:11:00"}
#' \dontrun{rbclientR(start.time, end.time, out.file='demo.json')}
#' \dontrun{scans <- createSelexScanList('demo.json')}
#' \dontrun{stormDetectionR(json.file='demo.json', ref.thresh=35, size.thresh=1000, out.file='demo.csv')}
#' \dontrun{storm.stats <- readStormStats('demo.csv.stats')}
#' \dontrun{storm.objs <- readStormObjects('demo.csv')}
#' \dontrun{storm.list<- createStormList(storm.objs, scans, storm.stats)}
#' \dontrun{summary(storm.list, verbosity=3)}
#' \dontrun{summary(storm.list, verbosity=2)}
#'
#'
#' @return Returns a data frame that summarises the storms in a list of storm
#' objects.

summary.stormList <- function(object, verbosity=1, ...) {
  out <- ldply(object, function(x) cbind(timestamp=x$timestamp,
    x$stats[,c(4:8,13:16)]))[,-1]
  switch(verbosity, out[ ,c(1,2,6,7)], out[ ,c(1,2,6,7,8,9)], out)
}
