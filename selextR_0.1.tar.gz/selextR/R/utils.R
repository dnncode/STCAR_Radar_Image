# Undocumented helper (anonymous) functions

# For use with ldply
rawStormToSpatialPoints <- function(raw1, selex.scan.list, storm.stats) {
  # raw1 is one whole storm object, with all the heights
  choose.scan <- sapply(selex.scan.list, function(x) x$timestamp ==
    raw1$dateTime[1])
  chosen.scans <- selex.scan.list[which(choose.scan)]

  out.list <- dlply(raw1, "z", rawStormHtToSpatialPoints, chosen.scans,
    storm.stats)

  hash.val <- digest(raw1)
  
  # Check the z-vals later (for 0-1 correctness)!!!
  sub.stats <- storm.stats[storm.stats$ID == raw1$storm.id[1], ]
  sub.stats <- sub.stats[ , -grep('[12345]', names(sub.stats))]
  sub.stats <- sub.stats[ , -c(1,2)]

  # Add the projection corrected centroid for the overall centroids. This is a
  # real hack!
  sub.stats$Centroid.x <- out.list[[1]]$stats$Centroid.x
  sub.stats$Centroid.y <- out.list[[1]]$stats$Centroid.y
  sub.stats$Ref.wt.centroid.x <- out.list[[1]]$stats$Ref.wt.centroid.x
  sub.stats$Ref.wt.centroid.y <- out.list[[1]]$stats$Ref.wt.centroid.y

  # Some clean-up to remove the additional overall centroid variables.
  for(ii in 1:length(out.list)) {
    tmp.len <- ncol(out.list[[ii]]$stats)
    out.list[[ii]]$stats <- out.list[[ii]]$stats[, -((tmp.len-3):tmp.len)]
  }

  out.list <- list(timestamp = raw1$dateTime[1], hash.val=hash.val,
    data=out.list, stats=sub.stats)
  class(out.list) <- "storm"
  out.list
}

# For use with ldply
rawStormHtToSpatialPoints <- function(raw2, chosen.scans, storm.stats) {
  # raw1 is one height of one storm object
  choose.sub.scan <- sapply(chosen.scans, function(x) x$height ==
    raw2$z[1])
  chosen.sub.scan <- chosen.scans[[which(choose.sub.scan)]]
  
  topleft.x <- coordinates(chosen.sub.scan$data[1,1])[1,1]
  topleft.y <- coordinates(chosen.sub.scan$data[1,1])[1,2]

  x.size <- getGridTopology(chosen.sub.scan$data)@cellsize[1]
  y.size <- getGridTopology(chosen.sub.scan$data)@cellsize[2]

  x.pts <- sapply(raw2$y, function(a) a*x.size + topleft.x, USE.NAMES=FALSE)
  y.pts <- sapply(raw2$x, function(a) topleft.y - a*y.size, USE.NAMES=FALSE)
  sp.pts <- SpatialPoints(cbind(x.pts, y.pts),
    CRS(proj4string(chosen.sub.scan$data)))
  sp.pts <- SpatialPointsDataFrame(sp.pts, data=data.frame(dBZ=raw2$dBZ))

  # get stats, get height, form list and return
  sub.stats <- storm.stats[storm.stats$ID == raw2$storm.id[1], ]
  c.x <- sub.stats$Centroid.x
  c.y <- sub.stats$Centroid.y
  r.c.x <- sub.stats$Ref.wt.centroid.x
  r.c.y <- sub.stats$Ref.wt.centroid.y

  sub.stats <- sub.stats[,grep(as.character(raw2$z[1]), names(sub.stats))]
  sub.stats <- sub.stats[,-grep("z", names(sub.stats))]
  tmp <- sub.stats[, grep("entroid", names(sub.stats))]
 
  sub.stats[,grep("\\.x", names(sub.stats))] <- 
    topleft.x + tmp[ , grep("y", names(tmp))]*x.size
  sub.stats[,grep("\\.y", names(sub.stats))] <- 
    topleft.y - tmp[ , grep("x", names(tmp))]*y.size

  sub.stats$Centroid.x <- topleft.x + c.y*x.size
  sub.stats$Centroid.y <- topleft.y - c.x*y.size
  sub.stats$Ref.wt.centroid.x <- topleft.x + r.c.y*x.size
  sub.stats$Ref.wt.centroid.y <- topleft.y - r.c.x*y.size

  height <- raw2$z[1]

  list(height=height, sp.pts=sp.pts, stats=sub.stats)
}

extractStormOutline <- function(storm.obj, height, convex.hull=FALSE) {
  # create grid object
  storm.data <- storm.obj$data
  id <- which(sapply(storm.data, function(x) x$height == height, 
    USE.NAMES=FALSE))

  if(length(id) == 0)
    return(NA)

  sp.pts <- storm.data[[id]]$sp.pts
  sp.grid <- points2grid(sp.pts)
  sp.grid <- SpatialGrid(sp.grid, proj4string=CRS(proj4string(sp.pts)))
  yes.no <- rep(0, length=prod(sp.grid@grid@cells.dim))

  id <- over(sp.pts, sp.grid)
  sp.grid <- SpatialGridDataFrame(sp.grid, data.frame(yes.no=yes.no))
  sp.grid$yes.no[id] <- 1

  sp.poly <- Grid2Polygons(sp.grid, level=TRUE, at=c(0,0.5,1))
  if(length(sp.poly) > 1) {
    id <- which(sp.poly$z == 0.75)
    sp.poly <- sp.poly[id,]
  }
  if(!convex.hull)
    return(as(sp.poly, "SpatialPolygons")) else
    return(as(gConvexHull(sp.poly), "SpatialPolygons"))
}
