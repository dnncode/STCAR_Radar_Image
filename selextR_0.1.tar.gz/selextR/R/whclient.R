#' CDOM data access 
#' 
#' Access CDOM data from R, implementing the Who, What, When, Where, Why, How
#' (WH) query framework. Reads data from CDOM server (or local cache) and
#' returns a data frame with proper header. User must have curl installed on
#' local linux machine.
#'
#' @param file File of local cache, e.g. 'wind_mean_hourly.csv'. Optional
#' argument. If the file (specified as fully qualified file name) exists, the data
#' will be read directly from the file instead of the CDOM server. Otherwise, the
#' data will be read from the CDOM server and written to the file as cache. If file
#' is not specified, the data will be read from the CDOM server.
#' @param dataset Undocumented.
#' @param host CDOM server IP address.
#' @param port CDOM port number.
#' @param field Field(s) to return, e.g. 'speed_x'. Optional argument. To return
#' more than one fields, enter all fields as a comma delimited list, e.g.
#' 'timestamp, speed_x'. Enter '' or '*' to return all fields in the dataset ('' is
#' the default value). To list all the available fields for a dataset, run
#' 'gdfield.py -d dataset'. To support result pagination, 'SKIP m LIMIT n' can be
#' used before the field names to skip the first m records and return the next n
#' records. Aggregation functions can also be applied to field names, e.g.
#' 'MAX(speed_x)'. For detailed information and syntax on aggregation functions,
#' refer to Informix manual on aggregation functions.
#' @param temporal Temporal filter. Optional argument. Only results in the given
#' temporal filter range will be returned. Temporal filter can be in one of the
#' following forms: i) time point, e.g. '2012-01-01 00:00:00'; ii) time period
#' represented as 'minimun_date_time, maximum_date_time', e.g. '2012-01-01
#' 00:00:00, 2012-12-31 23:59:59', take note that both minimum_date_time and
#' maximum_date_time are inclusive, i.e. they are included in the valid time range.
#' date_time should be formated as "YYYY-mm-dd HH:MM:SS".
#' @param spatial Spatial filter. Optional argument. Only results in the given
#' spatial filter range will be returned. Spatial filter can be in one of the
#' following forms: i) circle, represented as center point and radius,
#' 'center_point_latitude, center_point_longitude, radius_in_meter', e.g. '1.3666,
#' 103.7549, 1000'. If no radius is given, the query is treated as a nearest
#' neighbor query and a record closest to the given center will be returned. To
#' retrieve more than one nearest neighbors, use the SKIP and LIMIT in the 'field'
#' parameter; ii) rectangle, represented as upper left and bottom right corner
#' points, 'upper_left_point_latitude, upper_left_point_longitude,
#' bottom_right_point_latitude, bottom_right_point_longitude', e.g. '1.3666,
#' 103.7549, 1.3668, 103.7551'; iii) polygon, represented as all corner points,
#' 'point_1_latitude, point_1_longitude, point_2_latitude, point_2_longitude, ... ,
#' point_n_latitude, point_n_longitude', e.g. a triangle '1.3666, 103.7549, 1.3668,
#' 103.7551, 1.3672, 103.7581'.
#' @param condition Condition filter. Optional argument. This is an advanced
#' option to allow the use of more conditions to filter the results, e.g. 'speed_x
#' > -2'. A condition is represented as 'field operator value', where operator can
#' be on one of the following (case insensitive): =, <>, >, >=, <, <=, IN, BETWEEN,
#' LIKE, IS NULL, IS NOT NULL. Multiple conditions can be combined with 'AND' or
#' 'OR' (case insensitive), e.g. 'speed_x > -2 AND speed_y > -2'. For detailed
#' syntax on condition, refer to Informix manual on 'WHERE' clause in 'SELECT'
#' statement.
#' @param misc Misc option. Optional argument. This is an advanced option to
#' allow more options to control the results. Currently supported options are:
#' 'ORDER BY' and 'GROUP BY', e.g. 'ORDER BY speed_x' or 'GROUP BY station_id'.
#' 'ORDER BY' is used to specify the order of the results and 'GROUP BY' is used to
#' perform grouping for aggregation. For detailed information and syntax on misc
#' option, refer to Informix manual on 'GROUP BY' and 'ORDER BY' clauses in
#' 'SELECT' statement.
#'
#' @details This is an R wrapper to get data from the CDOM server. Note that the
#' user must have curl installed on the local machine. This version and the
#' examples have been tested on the NTU cluster.
#'
#' @examples 
#' \dontrun{data <- read.cdom("AirMonitoringStation.csv", 
#'   dataset="weather_monitoring_station", misc="order by name")}
#' \dontrun{head(data)}
#'
#' @export
#' @author Zhang Jun, Zhong Lun
#'
#' @return Data frame of requested data.

read.cdom <- function(file = "", dataset = "", field = "", temporal = "",
  spatial = "", condition = "", misc = "", host = "10.0.0.2", port = "8080") {

    # If the file exists, the data will be read directly from the file
    if (file != "") {
	    if (file.exists(file)) {
		    return(read.csv(file, header=TRUE, as.is=TRUE))
	    }
    }

    curl.cmd <- paste("http://", host, ":", port,
      "/CDOMServer/dataset/", dataset, "/wh.csv?", "field=", field, "&temporal=",
      temporal, "&spatial=", spatial, "&condition=", condition, "&misc=", misc,
      sep="")
    curl.cmd <- gsub(" ", "%20", curl.cmd)
    tmp.file <- tempfile()
    curl.cmd <- paste("curl -o ", tmp.file, curl.cmd, sep=" ")
    system(curl.cmd)

    # Return the data
    data <- read.csv(tmp.file, header=TRUE, as.is=TRUE)
    unlink(tmp.file)
    return(data)
}
