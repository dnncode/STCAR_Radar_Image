## A run through of all functions in the selextR package.
## Actually, this contains all the commands in the vignette, with the plots
## commented out.

library(selextR)
start.time <- "2011-05-20 07:04:00"
end.time <- "2011-05-20 07:25:00"
rbclientR(start.time, end.time, out.file='demo.json')

demo.out <- createSelexScanList('demo.json')
summary(demo.out)

# plot(demo.out[[14]], boundaries=TRUE)
# plot(demo.out[[11]], boundaries=TRUE)
# plot(spatAgg(demo.out[[14]], c(5,5)), boundaries=TRUE, xlim=c(0, 60000),
# ylim=c(0, 75000))

storm.list <- stormDetectionR(json.file='demo.json', out.file='demo.csv')
storm.stats.demo <- readStormStats('demo.csv.stats')
storm.list.demo <- readStormObjects('demo.csv')
storm.list.demo <- createStormList(storm.list.demo, demo.out, storm.stats.demo)
summary(storm.list.demo)

## Plotting a subset of the storms:
storm.list.demo.sub <- storm.list.demo[22:30]
# plot(storm.list.demo.sub)

## Plotting only the convex hull of each storm, at a different height:
# plot(storm.list.demo.sub, convex.hull=TRUE, height=5)

# plot(demo.out[[4]], storm.list.demo, boundaries=TRUE)
